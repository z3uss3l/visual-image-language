# VLR 3.2 – Diagnose der ersten Podman-Prüfung

## Befund vom Bazzite-System

Die erste Ausgabe von `./vlr-podman.sh doctor` zeigt:

- Podman ist installiert und verfügbar (`5.8.4`).
- Rootless-Betrieb ist aktiv.
- `/dev/dri` ist vorhanden.
- `/dev/kfd` ist vorhanden.
- Die Radeon-GPU-Geräte sind aus Sicht des Hosts erreichbar.
- `vlr-ollama` existiert noch nicht.
- `vlr-comfyui` existiert noch nicht.

### Das ist vor dem ersten Start kein Fehler.

Der Doctor prüft den **Bereitschaftszustand**, nicht ob die Container schon einmal gestartet wurden. Die Container werden erst beim ersten `start-ollama` bzw. `start-comfyui` angelegt.

## Wichtige Korrektur in VLR 3.2 failsafe2

Die erste VLR-3.2-Version hatte eine Konfigurationsüberschreibung in `vlr-podman.sh`, durch die der in `config/defaults.env` gesetzte ComfyUI-Imagewert wieder auf leer gesetzt werden konnte. Dadurch erschien im Status:

```json
"image": null
```

Das ist in `failsafe2` behoben. Der Default ist jetzt:

```text
VLR_COMFYUI_IMAGE=ghcr.io/ai-dock/comfyui:latest
```

## Warum `image` und `container` zwei verschiedene Dinge sind

- **Image**: lokal gespeicherte Container-Vorlage.
- **Container**: daraus erzeugte Laufzeitinstanz.

Vor dem ersten Start sind beide normalerweise noch nicht vorhanden.

Das gewünschte Verhalten ist:

```text
Doctor
  ↓
Podman/GPU OK
  ↓
start-ollama
  ↓
Image wird bei Bedarf gepullt
  ↓
Container wird erzeugt
  ↓
Ollama Healthcheck
  ↓
Qwen laden
```

und für ComfyUI entsprechend:

```text
start-comfyui
  ↓
Image wird bei Bedarf gepullt
  ↓
Container wird erzeugt
  ↓
/system_stats Healthcheck
  ↓
Generation
```

## Empfohlene nächste Prüfung

Noch **keine Bildgeneration** starten.

Zuerst:

```bash
./vlr-podman.sh doctor
```

Danach:

```bash
./vlr-podman.sh start-ollama
```

und anschließend:

```bash
./vlr-podman.sh status
```

Wenn Ollama gesund läuft, wird erst dann das vorhandene Qwen-Modell über den VLR-Endpunkt geprüft bzw. gepullt.

## GPU-Hinweis

Die vorhandenen `/dev/dri`- und `/dev/kfd`-Geräte bestätigen nur, dass die Host-Geräte vorhanden und für den rootless Podman-Kontext sichtbar sind. Sie beweisen noch nicht, dass Ollama tatsächlich die Radeon 780M für Inferenz verwendet.

Das wird erst mit dem ersten realen Containerlauf und den Ollama-/GPU-Logs verifiziert.

Für die Radeon 780M setzen wir Ollama auf Vulkan und aktivieren die iGPU-Auswahl. Einen `HSA_OVERRIDE_GFX_VERSION`-Override setzen wir nicht ohne konkreten Nachweis, dass der native Backend-Pfad ihn benötigt.
