from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_comfy_image_default_is_not_empty():
    text = (ROOT / "vlr-podman.sh").read_text()
    assert "VLR_COMFYUI_IMAGE:-ghcr.io/ai-dock/comfyui:latest" in text


def test_runtime_has_comfy_image_default():
    text = (ROOT / "vlr_runtime.py").read_text()
    assert 'VLR_COMFYUI_IMAGE", "ghcr.io/ai-dock/comfyui:latest"' in text
