import os
import unittest
from pathlib import Path

os.environ.setdefault('VLR_RUNTIME', 'native')

from vlr_runtime import RuntimeConfig, podman_exists, status

class RuntimeTests(unittest.TestCase):
    def test_default_ports_do_not_collide_with_native_defaults(self):
        c = RuntimeConfig()
        self.assertEqual(c.ollama_host_port, 11435)
        self.assertEqual(c.comfy_host_port, 8189)

    def test_status_is_safe_without_podman(self):
        s = status()
        self.assertIn('mode', s)
        self.assertIn('podman_available', s)

    def test_gpu_device_detection_is_host_based(self):
        # No hard-coded requirement: the runtime must remain importable on CI hosts.
        self.assertTrue(hasattr(RuntimeConfig, '__dataclass_fields__'))

    def test_legacy_database_migration_orders_columns_before_indexes(self):
        import sqlite3, tempfile
        import vlr_core
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / 'legacy.sqlite3'
            conn = sqlite3.connect(path)
            conn.execute("CREATE TABLE experiments(id TEXT PRIMARY KEY, created_at REAL NOT NULL, generation INTEGER)")
            conn.commit(); conn.close()
            conn = sqlite3.connect(path)
            cols = {r[1] for r in conn.execute("PRAGMA table_info(experiments)")}
            conn.close()
            self.assertNotIn('image_retained', cols)
            # Execute the same migration sequence used by init_db().
            conn = sqlite3.connect(path)
            migrations={'mutation_type':'TEXT','mutation_feedback':'TEXT','seed':'TEXT','image_path':'TEXT','image_retained':'INTEGER DEFAULT 1','is_winner':'INTEGER DEFAULT 0','is_best':'INTEGER DEFAULT 0'}
            cols={r[1] for r in conn.execute('PRAGMA table_info(experiments)')}
            for n,t in migrations.items():
                if n not in cols: conn.execute(f'ALTER TABLE experiments ADD COLUMN {n} {t}')
            conn.execute('CREATE INDEX IF NOT EXISTS idx_exp_retained ON experiments(image_retained)')
            conn.commit(); conn.close()

if __name__ == '__main__':
    unittest.main()
