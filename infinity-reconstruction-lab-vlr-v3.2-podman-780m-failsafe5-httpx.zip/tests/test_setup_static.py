import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class SetupStaticTests(unittest.TestCase):
    def test_setup_creates_all_required_source_dirs(self):
        text = (ROOT / 'setup.sh').read_text()
        self.assertIn('static,archive,logs,config,tests,config/quadlet', text)
        self.assertIn('python -m pip install', text)
        self.assertIn('psutil', text)
        self.assertIn('Setup startet keine KI-Runtime automatisch.', text)
        self.assertIn('config/defaults.env', text)

    def test_setup_wrapper_exists(self):
        p = ROOT / 'setup'
        self.assertTrue(p.is_file())
        self.assertTrue(p.stat().st_mode & 0o111)
        self.assertIn('setup setup.sh', (ROOT / 'setup.sh').read_text())
        self.assertIn('trap', (ROOT / 'setup.sh').read_text())

if __name__ == '__main__':
    unittest.main()
