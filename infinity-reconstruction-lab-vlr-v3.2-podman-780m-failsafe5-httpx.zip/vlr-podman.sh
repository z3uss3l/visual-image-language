#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ENV_FILE="${APP_DIR}/config/defaults.env"
[[ -f "$ENV_FILE" ]] && source "$ENV_FILE"
export VLR_RUNTIME=podman
PYTHON="${APP_DIR}/.venv/bin/python"
[[ -x "$PYTHON" ]] || PYTHON="$(command -v python3)"
export PODMAN_BIN="${PODMAN_BIN:-podman}"
export VLR_OLLAMA_IMAGE="${VLR_OLLAMA_IMAGE:-docker.io/ollama/ollama:latest}"
export VLR_OLLAMA_CONTAINER="${VLR_OLLAMA_CONTAINER:-vlr-ollama}"
export VLR_OLLAMA_VOLUME="${VLR_OLLAMA_VOLUME:-vlr-ollama-models}"
export VLR_OLLAMA_PORT="${VLR_OLLAMA_PORT:-11435}"
export VLR_COMFYUI_CONTAINER="${VLR_COMFYUI_CONTAINER:-vlr-comfyui}"
export VLR_COMFYUI_VOLUME="${VLR_COMFYUI_VOLUME:-vlr-comfyui-data}"
export VLR_COMFYUI_PORT="${VLR_COMFYUI_PORT:-8189}"
export VLR_COMFYUI_IMAGE="${VLR_COMFYUI_IMAGE:-}"

usage(){ echo "Usage: $0 {status|start-ollama|stop-ollama|start-comfyui|stop-comfyui|stop-all|pull-model|doctor}"; }
need(){ command -v "$PODMAN_BIN" >/dev/null || { echo "Podman fehlt." >&2; exit 2; }; }
status(){ "$PYTHON" - <<'PY'
from vlr_runtime import status
import json
print(json.dumps(status(), indent=2))
PY
}
start_ollama(){ "$PYTHON" - <<'PY'
from vlr_runtime import start_ollama
print(start_ollama())
PY
}
stop_ollama(){ "$PYTHON" - <<'PY'
from vlr_runtime import stop_ollama
print(stop_ollama())
PY
}
start_comfyui(){ "$PYTHON" - <<'PY'
from vlr_runtime import start_comfyui
print(start_comfyui())
PY
}
stop_comfyui(){ "$PYTHON" - <<'PY'
from vlr_runtime import stop_comfyui
print(stop_comfyui())
PY
}
stop_all(){ stop_comfyui || true; stop_ollama || true; }
pull_model(){ need; start_ollama; podman exec "$VLR_OLLAMA_CONTAINER" ollama pull "${1:-${OLLAMA_MODEL:-qwen3.8:27b}}"; stop_ollama; }
doctor(){
 need
 echo "Podman: $(podman --version)"
 echo "Rootless: $(podman info --format '{{.Host.Security.Rootless}}' 2>/dev/null || true)"
 echo "GPU devices:"; ls -l /dev/dri 2>/dev/null || echo '/dev/dri missing'
 [[ -e /dev/kfd ]] && ls -l /dev/kfd || true
 echo "Runtime status:"; status
}
need
case "${1:-}" in
 status) status;; start-ollama) start_ollama;; stop-ollama) stop_ollama;; start-comfyui) start_comfyui;; stop-comfyui) stop_comfyui;; stop-all) stop_all;; pull-model) pull_model "${2:-}";; doctor) doctor;; *) usage; exit 2;; esac
