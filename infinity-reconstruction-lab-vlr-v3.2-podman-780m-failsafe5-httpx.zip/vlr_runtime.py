"""VLR runtime orchestration.

Native mode talks to user-managed Ollama/ComfyUI processes.
Podman mode starts one managed AI container at a time and stops it at the end
of its phase. Persistent model volumes survive container removal/stop.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class RuntimeConfig:
    mode: str = field(default_factory=lambda: os.getenv("VLR_RUNTIME", "podman").lower())
    podman_bin: str = os.getenv("PODMAN_BIN", "podman")
    ollama_container: str = os.getenv("VLR_OLLAMA_CONTAINER", "vlr-ollama")
    comfy_container: str = os.getenv("VLR_COMFYUI_CONTAINER", "vlr-comfyui")
    ollama_image: str = os.getenv("VLR_OLLAMA_IMAGE", "docker.io/ollama/ollama:latest")
    comfy_image: str = os.getenv("VLR_COMFYUI_IMAGE", "")
    ollama_host_port: int = int(os.getenv("VLR_OLLAMA_PORT", "11435"))
    comfy_host_port: int = int(os.getenv("VLR_COMFYUI_PORT", "8189"))
    ollama_volume: str = os.getenv("VLR_OLLAMA_VOLUME", "vlr-ollama-models")
    comfy_volume: str = os.getenv("VLR_COMFYUI_VOLUME", "vlr-comfyui-data")
    start_timeout: int = int(os.getenv("VLR_RUNTIME_START_TIMEOUT", "180"))
    image_pull_timeout: int = int(os.getenv("VLR_IMAGE_PULL_TIMEOUT", "0"))
    stop_timeout: int = int(os.getenv("VLR_RUNTIME_STOP_TIMEOUT", "30"))
    vulkan: bool = os.getenv("VLR_OLLAMA_VULKAN", "1") != "0"
    igpu_enable: bool = os.getenv("VLR_OLLAMA_IGPU_ENABLE", "1") != "0"
    max_vram: int = int(os.getenv("VLR_OLLAMA_MAX_VRAM", "0"))


class RuntimeErrorState(RuntimeError):
    pass


def cfg() -> RuntimeConfig:
    return RuntimeConfig()


def podman_exists() -> bool:
    return shutil.which(cfg().podman_bin) is not None


def _run(*args: str, check: bool = True, timeout: Optional[int] = None,
         stream: bool = False) -> subprocess.CompletedProcess:
    c = cfg()
    try:
        if stream:
            # Image pulls can legitimately take many minutes. Do not capture the
            # stream or apply the short command/healthcheck timeout to them.
            proc = subprocess.run([c.podman_bin, *args], check=check)
            return subprocess.CompletedProcess([c.podman_bin, *args], proc.returncode)
        return subprocess.run([c.podman_bin, *args], text=True, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, check=check, timeout=timeout)
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        raise RuntimeErrorState(str(exc)) from exc


def _ensure_image(image: str) -> None:
    if not image:
        raise RuntimeErrorState("Kein Container-Image konfiguriert.")
    inspect = _run("image", "exists", image, check=False, timeout=10)
    if inspect.returncode == 0:
        return
    print(f"[VLR] Container-Image fehlt lokal: {image}", flush=True)
    print("[VLR] Starte Podman-Pull. Der Image-Pull hat absichtlich keinen kurzen Timeout.", flush=True)
    try:
        _run("pull", image, stream=True)
    except KeyboardInterrupt as exc:
        raise RuntimeErrorState("Podman-Image-Pull abgebrochen; kein Container wurde gestartet.") from exc
    verify = _run("image", "exists", image, check=False, timeout=10)
    if verify.returncode != 0:
        raise RuntimeErrorState(f"Podman-Pull beendet, aber Image ist nicht lokal verfügbar: {image}")
    print(f"[VLR] Image bereit: {image}", flush=True)


def _container_exists(name: str) -> bool:
    r = _run("container", "exists", name, check=False, timeout=5)
    return r.returncode == 0


def _container_running(name: str) -> bool:
    if not _container_exists(name):
        return False
    r = _run("inspect", "--format", "{{.State.Running}}", name, check=False, timeout=5)
    return r.returncode == 0 and r.stdout.strip().lower() == "true"


def _ensure_volume(name: str) -> None:
    _run("volume", "inspect", name, check=False, timeout=10)
    if _run("volume", "inspect", name, check=False, timeout=10).returncode != 0:
        _run("volume", "create", name, timeout=30)


def _gpu_args() -> list[str]:
    args: list[str] = []
    # Vulkan uses /dev/dri. /dev/kfd is harmless when present and helps Ollama
    # use ROCm on machines where it is supported. We never invent device paths.
    for dev in ("/dev/dri", "/dev/kfd"):
        if os.path.exists(dev):
            args += ["--device", dev]
    if os.path.exists("/dev/dri"):
        args += ["--group-add", "keep-groups"]
    return args


def _recreate(name: str) -> None:
    if _container_exists(name):
        _run("rm", "-f", name, check=False, timeout=30)


def start_ollama() -> dict:
    c = cfg()
    if not podman_exists():
        raise RuntimeErrorState("Podman ist nicht installiert/verfügbar.")
    _ensure_volume(c.ollama_volume)
    _ensure_image(c.ollama_image)
    if _container_running(c.ollama_container):
        return {"started": False, "running": True, "container": c.ollama_container}
    if _container_exists(c.ollama_container):
        _run("start", c.ollama_container, timeout=c.start_timeout)
    else:
        args = ["run", "-d", "--name", c.ollama_container,
                "-p", f"{c.ollama_host_port}:11434",
                "-v", f"{c.ollama_volume}:/root/.ollama",
                "--shm-size", "1g"]
        args += _gpu_args()
        if c.vulkan:
            args += ["-e", "OLLAMA_VULKAN=1"]
        if c.igpu_enable:
            args += ["-e", "OLLAMA_IGPU_ENABLE=1"]
        if c.max_vram > 0:
            args += ["-e", f"OLLAMA_MAX_VRAM={c.max_vram}"]
        args += [c.ollama_image]
        _run(*args, timeout=c.start_timeout)
    wait_http(f"http://127.0.0.1:{c.ollama_host_port}/api/tags", c.start_timeout,
              expected_port=c.ollama_host_port, host_network=True)
    return {"started": True, "running": True, "container": c.ollama_container}


def stop_ollama() -> dict:
    c = cfg()
    if not podman_exists() or not _container_exists(c.ollama_container):
        return {"stopped": False, "container": c.ollama_container}
    # Ask Ollama to unload first; container stop is the hard boundary.
    try:
        import requests
        requests.post(f"http://127.0.0.1:{c.ollama_host_port}/api/generate",
                      json={"model": os.getenv("OLLAMA_MODEL", ""), "prompt": "",
                            "stream": False, "keep_alive": 0}, timeout=15)
    except Exception:
        pass
    _run("stop", "-t", str(c.stop_timeout), c.ollama_container, check=False,
         timeout=c.stop_timeout + 10)
    return {"stopped": True, "container": c.ollama_container}


def start_comfyui() -> dict:
    c = cfg()
    if not podman_exists():
        raise RuntimeErrorState("Podman ist nicht installiert/verfügbar.")
    if not c.comfy_image:
        raise RuntimeErrorState("VLR_COMFYUI_IMAGE ist im Podman-Modus nicht gesetzt.")
    _ensure_volume(c.comfy_volume)
    _ensure_image(c.comfy_image)
    if _container_running(c.comfy_container):
        return {"started": False, "running": True, "container": c.comfy_container}
    if _container_exists(c.comfy_container):
        _run("start", c.comfy_container, timeout=c.start_timeout)
    else:
        args = ["run", "-d", "--name", c.comfy_container,
                "-p", f"{c.comfy_host_port}:8188",
                "-v", f"{c.comfy_volume}:/workspace",
                "--shm-size", "2g"]
        args += _gpu_args()
        args += [c.comfy_image]
        _run(*args, timeout=c.start_timeout)
    wait_http(f"http://127.0.0.1:{c.comfy_host_port}/system_stats", c.start_timeout,
              expected_port=c.comfy_host_port, host_network=True)
    return {"started": True, "running": True, "container": c.comfy_container}


def stop_comfyui() -> dict:
    c = cfg()
    if not podman_exists() or not _container_exists(c.comfy_container):
        return {"stopped": False, "container": c.comfy_container}
    try:
        import requests
        requests.post(f"http://127.0.0.1:{c.comfy_host_port}/free",
                      json={"unload_models": True, "free_memory": True}, timeout=10)
    except Exception:
        pass
    _run("stop", "-t", str(c.stop_timeout), c.comfy_container, check=False,
         timeout=c.stop_timeout + 10)
    return {"stopped": True, "container": c.comfy_container}


def wait_http(url: str, timeout: int, expected_port: int, host_network: bool = False) -> None:
    import requests
    deadline = time.time() + timeout
    last = "not ready"
    while time.time() < deadline:
        try:
            r = requests.get(url, timeout=2)
            if r.ok:
                return
            last = f"HTTP {r.status_code}"
        except requests.RequestException as exc:
            last = str(exc)
        time.sleep(1)
    raise RuntimeErrorState(f"Runtime auf Port {expected_port} wurde nicht bereit: {last}")


def status() -> dict:
    c = cfg()
    result = {"mode": c.mode, "podman_available": podman_exists(), "ollama": {}, "comfyui": {}}
    if podman_exists():
        result["ollama"] = {"container": c.ollama_container, "exists": _container_exists(c.ollama_container),
                            "running": _container_running(c.ollama_container), "port": c.ollama_host_port,
                            "image": c.ollama_image}
        result["comfyui"] = {"container": c.comfy_container, "exists": _container_exists(c.comfy_container),
                             "running": _container_running(c.comfy_container), "port": c.comfy_host_port,
                             "image": c.comfy_image or None}
    return result
