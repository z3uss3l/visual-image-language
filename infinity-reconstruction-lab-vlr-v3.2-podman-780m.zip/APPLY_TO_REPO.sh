#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-.}"
cd "$TARGET"

for f in app.py vlr_core.py vlr_runtime.py README.md setup.sh prepare-performance.sh storage-audit.sh vlr-podman.sh CONTAINER_RUNTIME.md verify.sh COMMIT_MESSAGE.txt; do
  mkdir -p "$(dirname "$f")"
  cp -f "$ROOT/$f" "$f"
done
mkdir -p static tests
cp -f "$ROOT/static/index_v3.html" static/index_v3.html
cp -f "$ROOT/tests/"test_*.py tests/

# The repository previously carried intermediate prototype ZIPs. They are release
# artifacts, not source, and are intentionally removed from the working tree.
for f in infinity-reconstruction-lab-vlr-v2.zip infinity-reconstruction-lab-vlr-v3.zip; do
  [[ -f "$f" ]] && git rm -f "$f" || true
done

./verify.sh

git diff --check
printf '\nReady for commit.\n'
printf 'Suggested commit: %s' "$(cat COMMIT_MESSAGE.txt)"
printf '\nThen: git add -A && git commit -F COMMIT_MESSAGE.txt && git push origin dev\n'
