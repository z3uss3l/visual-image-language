VLR 3.2 final verification
===========================
Target: Bazzite + Radeon 780M + 32 GB shared RAM
Runtime: Podman/Quadlet-capable, Vulkan, iGPU enabled

Checks:
- Python syntax: PASS
- Bash syntax: PASS
- JavaScript syntax: PASS
- Unit/smoke tests: PASS (7/7)
- Runtime command tests: PASS
- API tests: PASS
- Retention tests: PASS (included in prior V3 suite)

Not executed on target host:
- actual Radeon 780M container GPU inference
- actual Qwen3.8:27B pull/load
- actual ComfyUI generation

Safety:
- no system services disabled by release scripts
- no HSA override forced
- VLR_MAX_VRAM defaults to 0 (unbounded; memory gate remains controller responsibility)
- container Restart=no for phase isolation
