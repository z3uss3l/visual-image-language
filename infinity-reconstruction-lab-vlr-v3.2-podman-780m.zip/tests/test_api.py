import io
import os
import sys
import unittest
from PIL import Image, ImageDraw

os.environ['VLR_RUNTIME'] = 'native'
sys.path.insert(0, str(__import__('pathlib').Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
from app import app

class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app)
        im = Image.new('RGB', (128,128), 'white')
        ImageDraw.Draw(im).rectangle((20,20,100,100), outline='black', width=4)
        b = io.BytesIO(); im.save(b, 'PNG'); cls.data = b.getvalue()

    def test_health_and_runtime(self):
        self.assertEqual(self.client.get('/api/health').status_code, 200)
        self.assertEqual(self.client.get('/api/runtime').status_code, 200)

    def test_identical_images_score_one(self):
        r = self.client.post('/api/compare', files={
            'reference': ('a.png', self.data, 'image/png'),
            'candidate': ('b.png', self.data, 'image/png'),
        })
        self.assertEqual(r.status_code, 200)
        self.assertGreaterEqual(r.json()['composite'], 0.999)
        self.assertTrue(r.json()['threshold_98'])

if __name__ == '__main__':
    unittest.main()
