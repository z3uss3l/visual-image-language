import os
import unittest
from pathlib import Path

os.environ.setdefault('VLR_RUNTIME', 'native')

from vlr_runtime import RuntimeConfig, podman_exists, status

class RuntimeTests(unittest.TestCase):
    def test_default_ports_do_not_collide_with_native_defaults(self):
        c = RuntimeConfig()
        self.assertEqual(c.ollama_host_port, 11435)
        self.assertEqual(c.comfy_host_port, 8189)

    def test_status_is_safe_without_podman(self):
        s = status()
        self.assertIn('mode', s)
        self.assertIn('podman_available', s)

    def test_gpu_device_detection_is_host_based(self):
        # No hard-coded requirement: the runtime must remain importable on CI hosts.
        self.assertTrue(hasattr(RuntimeConfig, '__dataclass_fields__'))

if __name__ == '__main__':
    unittest.main()
