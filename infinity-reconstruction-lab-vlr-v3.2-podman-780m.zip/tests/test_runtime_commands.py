import os
import unittest
from unittest.mock import patch

os.environ.setdefault('VLR_RUNTIME', 'podman')
from vlr_runtime import start_ollama, start_comfyui, cfg

class RuntimeCommandTests(unittest.TestCase):
    def test_ollama_uses_non_conflicting_host_port_and_gpu_devices(self):
        calls=[]
        with patch('vlr_runtime.podman_exists', return_value=True), \
             patch('vlr_runtime._ensure_volume'), \
             patch('vlr_runtime._container_running', return_value=False), \
             patch('vlr_runtime._container_exists', return_value=False), \
             patch('vlr_runtime._run', side_effect=lambda *a, **k: calls.append(a)), \
             patch('vlr_runtime.wait_http'):
            start_ollama()
        flat=' '.join(' '.join(x) for x in calls)
        self.assertIn('-p 11435:11434', flat)
        self.assertIn('OLLAMA_VULKAN=1', flat)
        self.assertIn('OLLAMA_IGPU_ENABLE=1', flat)
        if os.path.exists('/dev/dri'):
            self.assertIn('/dev/dri', flat)

    def test_comfyui_requires_explicit_image(self):
        class C:
            comfy_image = ''
        with patch('vlr_runtime.cfg', return_value=C()), patch('vlr_runtime.podman_exists', return_value=True):
            from vlr_runtime import RuntimeErrorState
            with self.assertRaises(RuntimeErrorState):
                start_comfyui()

if __name__ == '__main__':
    unittest.main()
