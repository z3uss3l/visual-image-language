#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
DEST="${1:-.}"
[[ -d "$DEST/.git" ]] || { echo "Repository root expected: $DEST" >&2; exit 1; }
cp "$ROOT/app.py" "$DEST/app.py"
cp "$ROOT/vlr_core.py" "$DEST/vlr_core.py"
cp "$ROOT/setup.sh" "$DEST/setup.sh"
cp "$ROOT/README.md" "$DEST/README.md"
cp "$ROOT/.gitignore" "$DEST/.gitignore"
cp "$ROOT/prepare-performance.sh" "$DEST/prepare-performance.sh"
cp "$ROOT/storage-audit.sh" "$DEST/storage-audit.sh"
mkdir -p "$DEST/static"
cp "$ROOT/static/index_v3.html" "$DEST/static/index_v3.html"
rm -f "$DEST/static/index.html" "$DEST/infinity-reconstruction-lab-vlr-v2.zip"
chmod +x "$DEST/setup.sh" "$DEST/prepare-performance.sh" "$DEST/storage-audit.sh"
printf '%s\n' 'VLR v3 applied. Review git diff, then commit and push dev.'
