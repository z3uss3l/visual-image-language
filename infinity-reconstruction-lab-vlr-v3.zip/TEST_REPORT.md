# VLR v3 verification

Executed locally in a clean staging tree:

- Python AST / `py_compile`: PASS
- JavaScript `node --check`: PASS
- shell `bash -n` for setup/performance/storage/apply scripts: PASS
- FastAPI `/`, `/api/health`: PASS
- image comparison endpoint: PASS
- original image archive: PASS
- immutable original-description archive: PASS
- multipart metadata archive parsing: PASS
- retention cleanup: PASS
  - last generations retained
  - significant improvement milestones retained
  - winner/best protected
  - old image files removed while metadata remains
- MetaMaster archive endpoint: PASS

Not executable in this environment:

- real Ollama Qwen3.8:27B inference
- real Ollama unload confirmation on the user's machine
- real ComfyUI generation and `/free` memory confirmation
- GPU/RAM performance benchmark on the user's Radeon 750M

Those require the user's local runtime. The code therefore reports their runtime state instead of pretending those checks succeeded.
