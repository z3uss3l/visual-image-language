#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="${HOME}/Infinity-Reconstruction-Lab"
MODEL="${MODEL:-qwen3.8:27b}"
STATE_FILE="${APP_DIR}/.setup-state"
BACKUP_DIR="${APP_DIR}/.setup-backup"

log(){ printf '[%s] %s\n' "$(date '+%H:%M:%S')" "$*"; }
die(){ log "ERROR: $*"; exit 1; }

usage(){ cat <<'EOF'
Usage:
  ./setup.sh              Install/update the project in ~/Infinity-Reconstruction-Lab
  ./setup.sh --rollback   Remove only project-managed files
  ./setup.sh --help       Show this help

Default model: qwen3.8:27b
Override: MODEL='other-model' ./setup.sh

The setup does not install system services or remove system packages.
EOF
}

if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then usage; exit 0; fi

rollback(){
  log "Project-Rollback: nur projektverwaltete Dateien werden entfernt."
  if [[ -f "$STATE_FILE" ]]; then while IFS= read -r p; do [[ -e "$p" ]] && rm -rf "$p"; done < "$STATE_FILE"; fi
  rm -rf "$APP_DIR/.venv" "$APP_DIR/.setup-state" "$APP_DIR/.setup-backup" "$APP_DIR/run.sh" "$APP_DIR/prepare-performance.sh" "$APP_DIR/storage-audit.sh" "$APP_DIR/stop.sh" "$APP_DIR/config" "$APP_DIR/static" "$APP_DIR/app.py" "$APP_DIR/vlr_core.py" "$APP_DIR/README.md"
  rmdir "$APP_DIR" 2>/dev/null || true
}
if [[ "${1:-}" == "--rollback" || "${1:-}" == "--purge" ]]; then rollback; exit 0; fi
[[ "${1:-}" == "" || "${1:-}" == "install" ]] || die "Unbekannte Option: $1"

command -v python3 >/dev/null || die "python3 fehlt."
command -v curl >/dev/null || die "curl fehlt."
mkdir -p "$APP_DIR"/{static,archive,logs,config}
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

for f in app.py vlr_core.py README.md static/index_v3.html; do
  [[ -f "$APP_DIR/$f" ]] && { mkdir -p "$BACKUP_DIR/$(dirname "$f")"; cp -a "$APP_DIR/$f" "$BACKUP_DIR/$f"; }
  cp -f "$SCRIPT_DIR/$f" "$APP_DIR/$f"
  mkdir -p "$(dirname "$STATE_FILE")"; grep -Fqx "$APP_DIR/$f" "$STATE_FILE" 2>/dev/null || echo "$APP_DIR/$f" >> "$STATE_FILE"
done

cat > "$APP_DIR/config/defaults.env" <<CFG
OLLAMA_MODEL=$MODEL
OLLAMA_URL=http://127.0.0.1:11434
OLLAMA_TIMEOUT=600
OLLAMA_PHASE_KEEP_ALIVE=5m
COMFYUI_URL=http://127.0.0.1:8188
COMFYUI_WORKFLOW=$APP_DIR/config/comfyui-workflow.json
HOST=127.0.0.1
PORT=8765
RETENTION_LAST=5
RETENTION_KEEP_IMPROVEMENTS=1
RETENTION_MIN_IMPROVEMENT=0.005
CFG
printf '%s\n' "$APP_DIR/config/defaults.env" >> "$STATE_FILE"

python3 -m venv "$APP_DIR/.venv"
source "$APP_DIR/.venv/bin/activate"
python -m pip install --upgrade pip
python -m pip install --upgrade fastapi uvicorn python-multipart pillow numpy opencv-python-headless scikit-image requests psutil

cp -f "$SCRIPT_DIR/prepare-performance.sh" "$APP_DIR/prepare-performance.sh"
chmod +x "$APP_DIR/prepare-performance.sh"
printf '%s\n' "$APP_DIR/prepare-performance.sh" >> "$STATE_FILE"

cp -f "$SCRIPT_DIR/storage-audit.sh" "$APP_DIR/storage-audit.sh"
chmod +x "$APP_DIR/storage-audit.sh"
printf '%s\n' "$APP_DIR/storage-audit.sh" >> "$STATE_FILE"

cat > "$APP_DIR/run.sh" <<'RUN'
#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
source "$APP_DIR/config/defaults.env"
source "$APP_DIR/.venv/bin/activate"
"$APP_DIR/prepare-performance.sh" --apply
cd "$APP_DIR"
exec python app.py
RUN
chmod +x "$APP_DIR/run.sh"
printf '%s\n' "$APP_DIR/run.sh" >> "$STATE_FILE"

cat > "$APP_DIR/stop.sh" <<'STOP'
#!/usr/bin/env bash
pkill -f "python .*Infinity-Reconstruction-Lab/app.py" 2>/dev/null || true
STOP
chmod +x "$APP_DIR/stop.sh"
printf '%s\n' "$APP_DIR/stop.sh" >> "$STATE_FILE"

if command -v ollama >/dev/null 2>&1; then
  log "Ollama gefunden: $(ollama --version 2>/dev/null || true)"
  if curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    if ! curl -fsS http://127.0.0.1:11434/api/tags | grep -Fq 'qwen3.8:27b'; then
      log "WARNUNG: qwen3.8:27b ist lokal nicht sichtbar. Es wird nichts automatisch heruntergeladen."
    else
      log "qwen3.8:27b lokal vorhanden."
    fi
  else
    log "Ollama nicht erreichbar; starte es außerhalb des Setups."
  fi
else
  log "Ollama nicht installiert; für lokale VLR-Analyse separat installieren."
fi

log "VLR v3 Setup abgeschlossen."
log "Start: $APP_DIR/run.sh"
log "Browser: http://127.0.0.1:8765"
log "Retention default: letzte 5 Generationen + Verbesserungen + Gewinner/Best geschützt"
